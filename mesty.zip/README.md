# mesty-tailwind

To build css locally:
`npm run buildcss`
